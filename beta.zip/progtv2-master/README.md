# progtv2
new
possibilité de modifier les chaines dans le js (prop)
